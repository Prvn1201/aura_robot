########Important#########

Since the X3 Pi does not have jupyter, it cannot open the .ipynb file directly.
(The code inside cannot be directly converted into a py file, which will result in no output)

************************************************************

Therefore, we need to install the jupyter software.
Please enter the following command in the X3 Pi.

sudo pip3 install ipywidgets
sudo pip3 install jupyter
If the pip update error is reported, enter
pip install --upgrade pip
and then execute the above command

After installing jupyter, you need to ensure that the X3 Pi has a browser. The system comes with a Firefox

--------------------------------------------------------

Before running the .ipynb file, change the permissions of ttyUSBx first, otherwise the permissions are insufficient and the program will report an error in file opening and recognition.

(x: depends on whether the device in the /dev folder is newly appeared, the default is x:0)
***If it is not 0, the code should also be changed to the corresponding number. ***
The command to enter is:
sudo chmod 777 /dev/ttyUSBx x: the corresponding serial port number

-----------------------------------------------------------
After completing the above steps, you can open the shell terminal in the folder with the .ipynb file and enter the following command
jupyter-notebook
Then it will automatically pop up in the browser (if not, copy the URL that appears in the terminal and paste it into the browser)